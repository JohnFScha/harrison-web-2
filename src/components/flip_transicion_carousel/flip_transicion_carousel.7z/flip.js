import gsap from "../../../node_modules/gsap/index.js";
import { ScrollTrigger } from "../../../node_modules/gsap/ScrollTrigger.js";
import Lenis from "../../../node_modules/@studio-freight/lenis/dist/lenis.mjs";

const carouselCtn = document.getElementById("carousel-container");
const carousel = document.getElementById("carouselFig");

const svgFlip = document.getElementById("init");
const textFlip = document.getElementById("textAllCtn");
const socialEndCtn = document.getElementById("subTextContainer");

// if (carouselCtn.style.transform === "scale(1)") {
//   carousel.style.animation = "rotateAnim 30s infinite forwards";
// }

gsap.registerPlugin(ScrollTrigger);

const lenis = new Lenis();

function raf(time) {
  lenis.raf(time);
  requestAnimationFrame(raf);
}

requestAnimationFrame(raf);

const textTl = gsap.timeline({
  scrollTrigger: {
    trigger: ".carouselDiv",
    start: "top top",
    end: "bottom+=200% bottom",
    scrub: true,
    markers: true,
    pin: true,
    pinSpacing: false,
  },
});
textTl.staggerTo(
  ["#p1", "#p2"],
  1.5,
  {
    x: 0,
    duration: 20,
  },
  1
);

textTl.staggerTo(["#p1"], 1.5, { x: -2000, delay: 2, duration: 5 }, 0);

textTl.to("#p2", {
  y: 48,
  delay: 5,
  duration: 10,
});

textTl
  .to("#carousel-container", { transform: "scale(0.75)" }, "-=1")
  .timeScale(2);
textTl.to(".carouselDiv", { y: 800, opacity: 0, delay: 5, duration: 20 });

const outroAnim = gsap.timeline({
  scrollTrigger: {
    trigger: "#outroContainer",
    start: "center center",
    end: "bottom+=1000% bottom",
    markers: true,
    scrub: true,
    pin: true,
  },
  stagger: 2,
});

outroAnim.fromTo(
  "#init",
  {
    y: -1000,
    visibility: "hidden",

    opacity: 0,
  },
  {
    y: 0,
    visibility: "visible",
    opacity: 1,
    duration: 5,
    delay: 2,
  }
);
outroAnim.to("#init", {
  duration: 8,
  rotateY: 809,
});
outroAnim.to("#init", { visibility: "hidden" }).fromTo(
  "#textAllCtn",
  {
    visibility: "hidden",
    rotateY: 90,
    duration: 5,
  },
  { visibility: "visible", rotateY: 0, duration: 5 }
);
outroAnim.staggerTo(
  [".charSpan"],
  1,
  {
    color: "#D1D821",
    stagger: 1,
    duration: 10,
  },
  2
);

outroAnim.staggerTo(
  [textFlip],
  3,
  {
    scale: 0.6,
    y: -200,
  },
  1
);

outroAnim.to(socialEndCtn, {
  visibility: "visible",
});
outroAnim.fromTo(
  ".svgSocial",
  { scale: 0, duration: 10 },
  { scale: 1, duration: 10 }
);

outroAnim.staggerTo(
  [".charSpan2"],
  3,
  {
    color: "#D1D821",
    opacity: 1,
    duration: 25,
  },
  0.5
);
